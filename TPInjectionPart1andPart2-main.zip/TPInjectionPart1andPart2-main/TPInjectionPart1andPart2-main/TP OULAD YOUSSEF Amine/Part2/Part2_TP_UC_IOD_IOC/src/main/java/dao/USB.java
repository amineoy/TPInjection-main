package dao;

public interface USB {

    int read();
}
