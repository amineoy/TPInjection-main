package metier;

public interface IMetier {

    double calculer();
}
