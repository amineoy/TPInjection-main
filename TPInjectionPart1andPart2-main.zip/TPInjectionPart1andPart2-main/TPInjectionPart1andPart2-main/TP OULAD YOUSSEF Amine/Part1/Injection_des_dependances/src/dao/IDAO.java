package dao;

public interface IDAO {

     double getData();
}
