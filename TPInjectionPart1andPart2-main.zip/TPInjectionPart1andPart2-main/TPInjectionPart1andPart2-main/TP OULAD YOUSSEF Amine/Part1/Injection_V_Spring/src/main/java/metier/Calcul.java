package metier;

public class Calcul {

    public  double somme(double a,double b){
        return a+b;
    }
}
